package com.ramla.voiture.entities;

import org.springframework.data.rest.core.config.Projection;

@Projection(name = "marquev", types = { Voiture.class })
public interface VoitureProjection {
	public String getMarque();


}
