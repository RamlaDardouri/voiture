package com.ramla.voiture.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Albume {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long idAl;
private String nomAl;
private String descriptionAl;
@JsonIgnore
@OneToMany(mappedBy = "albume")
private List<Voiture> voitures;

	
	
	public Albume(String nomAl, String descriptionAl, List<Voiture> voitures)
	{

	super();
	this.nomAl = nomAl;
	this.descriptionAl = descriptionAl;
	this.voitures = voitures;
	}
	public Long getIdAl() {
	return idAl;
	}
	public void setIdAl(Long idAl) {
	this.idAl = idAl;
	}
	public String getNomAl() {
	return nomAl;
	}
	public void setNomAl(String nomAl) {
	this.nomAl = nomAl;
	}
	public String getDescriptionAl() {
	return descriptionAl;
	}
	public void setDescriptionAl(String descriptionAl) {
	this.descriptionAl = descriptionAl;
	}
	public List<Voiture> getVoitures() {
	return voitures;
	}
	public void setVoitures(List<Voiture> voitures) {
	this.voitures = voitures;
	}
	}

