package com.ramla.voiture.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.ManyToOne;
import javax.persistence.ManyToOne;

@Entity
public class Voiture {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idVoiture;
	private String marque;
	private String matricule;
	private Double prix;
	private Date dateVente;

	@ManyToOne
	private Albume albume;
	
	public Voiture() {
		super();
	}
	public Voiture(String marque,String matricule ,Double prix, Date dateVente) {
	super();
	this.marque = marque;
	this.matricule = matricule;
	this.prix=prix;
	this.dateVente = dateVente;
	}
	
	public Long getIdVoiture() {
		return idVoiture;
		}
		public void setIdVoiture(Long idVoiture) {
		this.idVoiture = idVoiture;
		}
		public String getMarque() {
		return marque;
		}
		public void setMarque(String marque) {
		this.marque = marque;
		}
		public String getMatricule() {
			return matricule;
			}
			public void setMatricule(String matricule) {
			this.matricule = matricule;
			}
		public Double getPrix() {
		return prix;
		}
		public void setPrix(Double prix) {
		this.prix= prix;
		}
		public Date getDateVente() {
		return dateVente;
		}
		public void setDateVente(Date dateVente) {
		this.dateVente = dateVente;
		}
		@Override
		public String toString() {
			return "Voiture [idVoiture=" + idVoiture + ", marque=" + marque + ", matricule=" + matricule + ", prix="
					+ prix + ", dateVente=" + dateVente + "]";
		}
		public Albume getAlbume() {
			return albume;
		}
		public void setAlbume(Albume albume) {
			this.albume = albume;
		}
		
    
}
