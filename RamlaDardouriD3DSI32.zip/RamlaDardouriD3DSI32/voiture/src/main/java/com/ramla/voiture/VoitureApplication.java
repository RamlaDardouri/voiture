package com.ramla.voiture;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ramla.voiture.entities.Voiture;
import com.ramla.voiture.service.VoitureService;

@SpringBootApplication
public class VoitureApplication implements CommandLineRunner  {
	@Autowired
	VoitureService voitureService;

	public static void main(String[] args) {
		SpringApplication.run(VoitureApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	/*voitureService.saveVoiture(new Voiture("clio","123 4789 TN", 260000.0, new Date()));
	voitureService.saveVoiture(new Voiture("symbole3","140 7412 TN", 27500.0, new Date()));
	voitureService.saveVoiture(new Voiture("260","120 9514 TN", 5000.0, new Date()));
	}*/

	}}
