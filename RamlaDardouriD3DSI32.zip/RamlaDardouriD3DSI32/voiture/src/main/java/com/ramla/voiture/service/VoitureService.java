package com.ramla.voiture.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.ramla.voiture.entities.Albume;
import com.ramla.voiture.entities.Voiture;

public interface VoitureService {
	
	Voiture saveVoiture(Voiture v);
	Voiture updateVoiture(Voiture v);
	void deleteVoiture(Voiture v);
	 void deleteVoitureById(Long id);
	Voiture getVoiture(Long id);
	List<Voiture> getAllVoiture();
	Page<Voiture> getAllVoitureParPage(int page, int size);
	
	List<Voiture> findByMarque(String marquev);
	List<Voiture> findByNomMarqueContains(String marquev);
	List<Voiture> findByMarquePrix (String marque, Double prix);
	List<Voiture> findByAlbume (Albume albume);
	List<Voiture> findByAlbumeIdAl(Long id);
	List<Voiture> findByOrderByMarqueAsc();
	List<Voiture> trierMarquePrix();
	}



