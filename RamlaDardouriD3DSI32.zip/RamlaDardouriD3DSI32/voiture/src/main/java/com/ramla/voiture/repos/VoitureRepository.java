package com.ramla.voiture.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ramla.voiture.entities.Albume;
import com.ramla.voiture.entities.Voiture;

public interface VoitureRepository extends JpaRepository<Voiture, Long> {

	List<Voiture> findByMarque(String marquev);
	List<Voiture> findByMarqueContains(String marquev);


	
	/*@Query("select v from Voiture v where v.marque like %?1 and v.prix >?2")
	List<Voiture> findByMarquePrix (String marque, Double prix);*/
	
	@Query("select v from Voiture v where v.marque like %:marquev and v.prix>:prixv")
	List<Voiture> findByMarquePrix (@Param("marquev") String marque,@Param("prixv") Double prix);
	
	
	@Query("select v from Voiture v where v.albume = ?1")
	List<Voiture> findByAlbume (Albume albume);
	
	List<Voiture> findByAlbumeIdAl(Long id);
	
	List<Voiture> findByOrderByMarqueAsc();
	
	@Query("select v from Voiture v order by v.marque ASC, v.prix DESC")
	List<Voiture> trierMarquePrix ();
	
	
	

}
