package com.ramla.voiture.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.ramla.voiture.entities.Albume;
import com.ramla.voiture.entities.Voiture;
import com.ramla.voiture.repos.VoitureRepository;

@Service
public class VoitureServiceImpl implements VoitureService {
	@Autowired
	VoitureRepository voitureRepository;
	@Override
	public Voiture saveVoiture(Voiture v) {
	return voitureRepository.save(v);
	}
	@Override
	public Voiture updateVoiture(Voiture v) {
	return voitureRepository.save(v);
	}
	@Override
	public void deleteVoiture(Voiture v) {
	voitureRepository.delete(v);
	}
	 @Override
	public void deleteVoitureById(Long id) {
	voitureRepository.deleteById(id);
	}
	@Override
	public Voiture getVoiture(Long id) {
	return voitureRepository.findById(id).get();
	}
	@Override
	public List<Voiture> getAllVoiture() {
	return voitureRepository.findAll();
	}
	
	@Override
	public Page<Voiture> getAllVoitureParPage(int page, int size) {
	return voitureRepository.findAll(PageRequest.of(page, size));
	}
	@Override
	public List<Voiture> findByMarque(String marquev) {
		return voitureRepository.findByMarque(marquev);
	}
	@Override
	public List<Voiture> findByNomMarqueContains(String marquev) {
		return voitureRepository.findByMarqueContains(marquev);
		
	}
	@Override
	public List<Voiture> findByMarquePrix(String marque, Double prix) {
		return voitureRepository.findByMarquePrix(marque, prix);
	}
	@Override
	public List<Voiture> findByAlbume(Albume albume) {
		return voitureRepository.findByAlbume(albume);
	}
	@Override
	public List<Voiture> findByAlbumeIdAl(Long id) {
		return voitureRepository.findByAlbumeIdAl(id);
	}
	@Override
	public List<Voiture> findByOrderByMarqueAsc() {
		return voitureRepository.findByOrderByMarqueAsc();
	}
	@Override
	public List<Voiture> trierMarquePrix() {
		return voitureRepository.trierMarquePrix();
	}

	
	
	
	
}
