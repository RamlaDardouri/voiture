package com.ramla.voiture;



import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;

import com.ramla.voiture.entities.Albume;
import com.ramla.voiture.entities.Voiture;
import com.ramla.voiture.repos.VoitureRepository;
import com.ramla.voiture.service.VoitureService;

@SpringBootTest
class VoitureApplicationTests {
@Autowired
private VoitureRepository voitureRepository;
private VoitureService voitureService ;
@Test
public void testCreateVoiture() {
Voiture v1 = new Voiture("citroine","120 2357 tn",45.500 ,new Date());
voitureRepository.save(v1);
}

@Test
public void testFindVoiture()
{
 Voiture v = voitureRepository.findById(15L).get();
System.out.println(v);
}
@Test
public void testUpdateVoiture()
{
Voiture v = voitureRepository.findById(15L).get();
v.setPrix(71.0);
voitureRepository.save(v);
}
@Test
public void testDeleteVoiture()
{
voitureRepository.deleteById(2L);;
}


@Test
public void testListerTousVoitures()
{
List<Voiture> v1 = voitureRepository.findAll();
for (Voiture v: v1)
{
System.out.println(v);
}
}

@Test
public void testFindVoitureByMarque()
{
 List<Voiture> v1 = voitureRepository.findByMarque("BMW");
 for (Voiture v: v1)
 {
 System.out.println(v);
 }
}

@Test
public void testFindVoitureByMarqueContains()
{
 List<Voiture> v1 = voitureRepository.findByMarqueContains("c");
 for (Voiture v: v1)
 {
 System.out.println(v);
 }
}

@Test
public void testfindByMarquePrix()
{
List<Voiture> v1 = voitureRepository.findByMarquePrix("symbole3",100.0);
for (Voiture v : v1)
{
System.out.println(v);
}

}


@Test
public void testfindByAlbume()
{
Albume al = new Albume();
al.setIdAl(4L);
List<Voiture> v1 = voitureRepository.findByAlbume(al);
for (Voiture v :v1)
{
System.out.println(v);
}
}

@Test
public void findByAlbumeIdAl()
{
List<Voiture> v1 = voitureRepository.findByAlbumeIdAl(3L);
for (Voiture v : v1)
{
System.out.println(v);
}

}

@Test
public void testfindByOrderByMarquAsc()
{
List<Voiture> v1=voitureRepository.findByOrderByMarqueAsc();
for (Voiture v : v1)
{
System.out.println(v);
}

}


@Test
public void testTrierMarquePrix()
{
List<Voiture> v1 = voitureRepository.trierMarquePrix();
for (Voiture v : v1)
{
System.out.println(v);
}

}

@Test
public void testFindByNomVoitureContains()
{
Page<Voiture> v = voitureService.getAllVoitureParPage(0,3);
System.out.println(v.getSize());
System.out.println(v.getTotalElements());
System.out.println(v.getTotalPages());

v.getContent().forEach(v1 -> {System.out.println(v1.toString());
});

}




}
